
// Este arquivo foi esvaziado pois a aplicação agora utiliza Vanilla JS puro embutido no index.html.
export {};
