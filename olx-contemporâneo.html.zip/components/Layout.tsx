
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, User, MessageCircle, LogOut, ShieldCheck, Bell, MapPin, ChevronDown } from 'lucide-react';
import { ADMIN_WHATSAPP } from '../constants';
import { User as UserType } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: UserType | null;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const navigate = useNavigate();
  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen flex flex-col bg-[#f6f6f6]">
      {/* Header Superior Roxo */}
      <header className="bg-olx-purple sticky top-0 z-50 shadow-md">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          {/* Logo Estilo OLX */}
          <Link to="/" className="flex items-center gap-1 shrink-0">
            <span className="text-3xl font-black text-white tracking-tighter">OLX</span>
            <span className="text-sm font-medium text-purple-200 self-end mb-1 hidden sm:block">Contemporâneo</span>
          </Link>

          {/* Barra de Busca Integrada */}
          <div className="flex-1 max-w-3xl flex items-center bg-white rounded-lg overflow-hidden h-10 shadow-sm">
            <div className="flex-1 flex items-center px-3 border-r border-gray-100">
              <Search className="w-4 h-4 text-gray-400 mr-2" />
              <input 
                type="text" 
                placeholder="Estou procurando por..."
                className="w-full h-full border-none focus:ring-0 outline-none text-sm text-gray-700"
              />
            </div>
            <div className="hidden md:flex items-center px-3 gap-1 text-gray-400 border-r border-gray-100 hover:bg-gray-50 cursor-pointer min-w-[140px]">
              <MapPin className="w-4 h-4" />
              <span className="text-xs font-medium truncate">Contemporâneo</span>
            </div>
            <button className="bg-olx-orange h-full px-5 text-white hover:bg-olx-orange/90 transition-colors">
              <Search className="w-5 h-5" />
            </button>
          </div>

          {/* Ações Direita */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {user ? (
              <div className="flex items-center gap-1 sm:gap-4">
                <Link to="/meus-anuncios" title="Mensagens" className="p-2 text-white hover:bg-white/10 rounded-full hidden sm:block">
                  <MessageCircle className="w-6 h-6" />
                </Link>
                <button title="Notificações" className="p-2 text-white hover:bg-white/10 rounded-full hidden sm:block">
                  <Bell className="w-6 h-6" />
                </button>
                <div className="relative group">
                  <button className="flex items-center gap-1 text-white hover:bg-white/10 px-2 py-1 rounded-lg transition-colors">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center font-bold text-xs">
                      {user.name[0].toUpperCase()}
                    </div>
                    <ChevronDown className="w-4 h-4 hidden sm:block" />
                  </button>
                  <div className="absolute right-0 mt-2 w-56 bg-white border border-gray-200 rounded-xl shadow-2xl py-2 invisible group-hover:visible opacity-0 group-hover:opacity-100 transition-all z-50">
                    <div className="px-4 py-3 border-b border-gray-100 mb-2">
                      <p className="text-sm font-bold text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-400 truncate">{user.email}</p>
                    </div>
                    {isAdmin && (
                      <Link to="/admin" className="block px-4 py-2 hover:bg-olx-purple/5 text-olx-purple font-bold text-sm">Painel do Administrador</Link>
                    )}
                    <Link to="/meus-anuncios" className="block px-4 py-2 hover:bg-gray-50 text-gray-700 text-sm font-medium">Meus anúncios</Link>
                    <button onClick={onLogout} className="w-full text-left px-4 py-2 hover:bg-red-50 text-red-600 text-sm font-medium">Sair</button>
                  </div>
                </div>
              </div>
            ) : (
              <Link to="/login" className="text-white text-sm font-bold hover:underline px-2">Entrar</Link>
            )}

            <Link 
              to="/anunciar" 
              className="bg-olx-orange hover:bg-olx-orange/90 text-white px-4 sm:px-6 py-2 rounded-full font-black uppercase text-[10px] sm:text-xs shadow-md transition-all whitespace-nowrap"
            >
              Anunciar
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer minimalista Estilo OLX */}
      <footer className="bg-white border-t border-gray-200 py-10 px-4 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-8">
          <div className="space-y-4">
            <span className="text-2xl font-black text-olx-purple tracking-tighter">OLX</span>
            <p className="text-xs text-gray-400 max-w-xs leading-relaxed">
              © 2024 OLX Contemporâneo. Marketplace exclusivo para moradores. Todos os direitos reservados.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-10">
            <div className="space-y-2">
              <h4 className="text-sm font-bold text-gray-900">Sobre</h4>
              <ul className="text-xs text-gray-500 space-y-1">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/cadastro">Como funciona</Link></li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-bold text-gray-900">Ajuda</h4>
              <ul className="text-xs text-gray-500 space-y-1">
                <li><a href={`https://wa.me/${ADMIN_WHATSAPP}`} target="_blank">Falar com Admin</a></li>
                <li><Link to="/login">Minha conta</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
