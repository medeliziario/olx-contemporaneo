
export const ADMIN_EMAIL = 'lluizpaulos@gmail.com';
export const ADMIN_WHATSAPP = '5521968223436';
export const SUBSCRIPTION_FEE = 10;
export const PIX_KEY = 'luiz-paulo-eliziario-da@jim.com';