
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { User } from './types';
import { db } from './database';
import Layout from './components/Layout';

// Pages
import HomePage from './pages/Home';
import LoginPage from './pages/Login';
import RegisterPage from './pages/Register';
import ListingDetail from './pages/ListingDetail';
import CreateListing from './pages/CreateListing';
import MyListings from './pages/MyListings';
import AdminDashboard from './pages/admin/Dashboard';
import StatusPage from './pages/StatusPage';

// Componente de Bloqueio Genérico
const LockPage = ({ title, desc, color }: { title: string, desc: string, color: string }) => (
  <div className="max-w-xl mx-auto py-32 text-center bg-white rounded-[40px] m-4 p-12 shadow-xl border border-gray-100">
    <h1 className={`text-3xl font-black mb-4 ${color}`}>{title}</h1>
    <p className="text-gray-400 font-medium">{desc}</p>
    <button 
      onClick={() => { db.setSession(null); window.location.href = '#/login'; }} 
      className="mt-10 text-olx-purple font-black uppercase text-sm"
    >
      Sair da conta
    </button>
  </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userId = db.getSession();
    if (userId) {
      const found = db.getUserById(userId);
      if (found) setUser(found);
    }
    setLoading(false);
  }, []);

  const handleLogin = (u: User) => {
    db.setSession(u.id);
    setUser(u);
  };

  const handleLogout = () => {
    db.setSession(null);
    setUser(null);
  };

  if (loading) return null;

  const isBlocked = user?.residentStatus === 'blocked';
  const isRejected = user?.residentStatus === 'rejected';
  const isPending = user?.residentStatus === 'pending' && user?.role !== 'admin';
  const isApproved = user?.residentStatus === 'approved';

  return (
    <Router>
      <Layout user={user} onLogout={handleLogout}>
        <Routes>
          {/* Rotas Públicas Iniciais */}
          <Route path="/login" element={!user ? <LoginPage onLogin={handleLogin} /> : <Navigate to="/" />} />
          <Route path="/cadastro" element={!user ? <RegisterPage onLogin={handleLogin} /> : <Navigate to="/" />} />
          
          {/* Telas de Restrição Específicas */}
          <Route path="/blocked" element={isBlocked ? <LockPage title="Conta Bloqueada" desc="Seu acesso foi desativado pelo administrador Luiz Paulo." color="text-red-600" /> : <Navigate to="/" />} />
          <Route path="/denied" element={isRejected ? <LockPage title="Acesso Negado" desc="Seu cadastro foi recusado pela administração." color="text-gray-700" /> : <Navigate to="/" />} />
          <Route path="/status" element={user ? <StatusPage user={user} /> : <Navigate to="/login" />} />

          {/* Lógica de Redirecionamento de Segurança por Status */}
          {isBlocked && <Route path="*" element={<Navigate to="/blocked" replace />} />}
          {isRejected && <Route path="*" element={<Navigate to="/denied" replace />} />}
          {isPending && <Route path="*" element={<Navigate to="/status" replace />} />}

          {/* Rotas para Usuários Aprovados ou Admin */}
          <Route path="/" element={<HomePage user={user} />} />
          <Route path="/listing/:id" element={<ListingDetail user={user} />} />
          
          <Route path="/anunciar" element={isApproved ? <CreateListing user={user!} /> : <Navigate to="/status" />} />
          <Route path="/meus-anuncios" element={user ? <MyListings user={user} /> : <Navigate to="/login" />} />
          
          {/* Rota Admin Protegida */}
          <Route path="/admin" element={user?.role === 'admin' ? <AdminDashboard /> : <Navigate to="/" />} />

          {/* Fallback para home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
