
export type UserRole = 'resident' | 'admin';
export type ResidentStatus = 'pending' | 'approved' | 'rejected' | 'blocked';
export type ListingStatus = 'pending' | 'approved' | 'rejected' | 'paused';
export type UserPlan = 'basic' | 'premium' | 'pro';

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  whatsapp: string;
  block: string;
  apartment: string;
  role: UserRole;
  residentStatus: ResidentStatus;
  subscriberActive: boolean;
  subscriptionExpiresAt?: string; // Data de expiração do acesso
  planType?: UserPlan;
  createdAt: string;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  userId: string;
  userName: string;
  userBlock: string;
  whatsappContact: string;
  status: ListingStatus;
  isFeatured?: boolean;
  rejectionReason?: string;
  createdAt: string;
}

export interface Report {
  id: string;
  listingId: string;
  userId: string;
  reason: string;
  status: 'open' | 'resolved';
  createdAt: string;
}

export const CATEGORIES = [
  'Saúde e Beleza',
  'Venda',
  'Troca',
  'Pet',
  'Automóveis',
  'Móveis',
  'Eletrônicos',
  'Esportes',
  'Brinquedos',
  'Serviços',
  'Imóveis',
  'Outros'
];
