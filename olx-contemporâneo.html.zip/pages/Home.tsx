
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Tag, Clock, MapPin, Sparkles, Smartphone, Sofa, Bike, Car, Home as HomeIcon, Briefcase, Gift, Layers, Heart, ShoppingBag, RefreshCw, Dog } from 'lucide-react';
import { db } from '../database';
import { User, CATEGORIES } from '../types';

const CATEGORY_ICONS: Record<string, any> = {
  'Saúde e Beleza': Heart,
  'Venda': ShoppingBag,
  'Troca': RefreshCw,
  'Pet': Dog,
  'Automóveis': Car,
  'Móveis': Sofa,
  'Eletrônicos': Smartphone,
  'Esportes': Bike,
  'Brinquedos': Layers,
  'Serviços': Briefcase,
  'Imóveis': HomeIcon,
  'Outros': Tag
};

const HomePage: React.FC<{ user: User | null }> = ({ user }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  
  const listings = useMemo(() => {
    const allUsers = db.getUsers();
    const activeUserIds = allUsers
      .filter(u => u.residentStatus === 'approved')
      .map(u => u.id);

    return db.getListings()
      .filter(l => l.status === 'approved' && activeUserIds.includes(l.userId))
      .filter(l => selectedCategory === 'Todas' || l.category === selectedCategory)
      .sort((a, b) => {
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [selectedCategory]);

  return (
    <div className="bg-[#f6f6f6] min-h-screen">
      {/* Navegação de Categorias com Ícones (Estilo OLX) */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6 overflow-x-auto scrollbar-hide">
          <div className="flex items-center gap-6 sm:gap-12 min-w-max">
            <button 
              onClick={() => setSelectedCategory('Todas')}
              className="flex flex-col items-center gap-2 group transition-all"
            >
              <div className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all ${selectedCategory === 'Todas' ? 'border-olx-purple bg-olx-purple/5' : 'border-gray-100 bg-gray-50 group-hover:border-olx-purple/30'}`}>
                <Layers className={`w-6 h-6 ${selectedCategory === 'Todas' ? 'text-olx-purple' : 'text-gray-400'}`} />
              </div>
              <span className={`text-xs font-bold ${selectedCategory === 'Todas' ? 'text-olx-purple' : 'text-gray-500'}`}>Todas</span>
            </button>
            {CATEGORIES.map(cat => {
              const Icon = CATEGORY_ICONS[cat] || Tag;
              return (
                <button 
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className="flex flex-col items-center gap-2 group transition-all"
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all ${selectedCategory === cat ? 'border-olx-purple bg-olx-purple/5' : 'border-gray-100 bg-gray-50 group-hover:border-olx-purple/30'}`}>
                    <Icon className={`w-6 h-6 ${selectedCategory === cat ? 'text-olx-purple' : 'text-gray-400'}`} />
                  </div>
                  <span className={`text-xs font-bold ${selectedCategory === cat ? 'text-olx-purple' : 'text-gray-500'}`}>{cat}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar de Filtros (Estilo OLX) */}
          <aside className="hidden lg:block w-64 shrink-0">
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-black text-gray-900 mb-4">Filtrar por</h3>
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-4">Localização</h4>
                    <p className="text-sm font-bold text-gray-800 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-olx-purple" /> Contemporâneo
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-4">Categoria</h4>
                    <div className="space-y-2">
                       {['Todas', ...CATEGORIES].map(cat => (
                         <button 
                          key={cat}
                          onClick={() => setSelectedCategory(cat)}
                          className={`block text-sm transition-colors ${selectedCategory === cat ? 'text-olx-purple font-bold' : 'text-gray-500 hover:text-gray-900'}`}
                         >
                           {cat}
                         </button>
                       ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Área de Anúncios */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
               <h2 className="text-xl font-bold text-gray-900">
                 {selectedCategory === 'Todas' ? 'Anúncios recentes' : `Resultados para ${selectedCategory}`}
               </h2>
               <span className="text-xs text-gray-400 font-medium">{listings.length} anúncios encontrados</span>
            </div>

            {listings.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {listings.map(listing => (
                  <Link 
                    key={listing.id} 
                    to={`/listing/${listing.id}`}
                    className={`bg-white rounded-lg overflow-hidden border transition-all hover:shadow-lg ${listing.isFeatured ? 'border-amber-400 ring-1 ring-amber-400/20 shadow-md' : 'border-gray-100'} flex flex-col h-full`}
                  >
                    <div className="relative aspect-[4/3] bg-gray-100 overflow-hidden">
                      {listing.isFeatured && (
                        <div className="absolute top-2 left-2 z-10 bg-amber-400 text-amber-900 px-2 py-0.5 rounded text-[10px] font-black uppercase flex items-center gap-1 shadow">
                          <Sparkles className="w-3 h-3" /> Destaque
                        </div>
                      )}
                      <img 
                        src={listing.images[0]} 
                        alt={listing.title}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      />
                    </div>
                    <div className="p-4 flex flex-col flex-1">
                      <h3 className="text-sm font-medium text-gray-900 line-clamp-2 leading-tight mb-2 h-10">
                        {listing.title}
                      </h3>
                      <p className="text-xl font-black text-gray-900 mb-4">
                        {listing.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                      <div className="mt-auto space-y-1">
                         <div className="flex items-center justify-between text-[10px] font-bold text-gray-400 uppercase tracking-tight">
                            <span className="flex items-center gap-1">
                               <MapPin className="w-3 h-3 text-olx-purple" /> Bloco {listing.userBlock}
                            </span>
                            <span className="flex items-center gap-1">
                               <Clock className="w-3 h-3" /> {new Date(listing.createdAt).toLocaleDateString('pt-BR')}
                            </span>
                         </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-20 text-center border border-dashed border-gray-200">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                   <Tag className="w-10 h-10 text-gray-200" />
                </div>
                <h3 className="text-xl font-black text-gray-900">Nenhum anúncio nesta categoria</h3>
                <p className="text-gray-400 mt-2">Que tal ser o primeiro a anunciar algo aqui?</p>
                <Link to="/anunciar" className="inline-block mt-8 bg-olx-purple text-white px-8 py-3 rounded-full font-black uppercase text-sm shadow-md">Publicar Agora</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
