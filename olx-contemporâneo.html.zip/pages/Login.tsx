
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Mail, Lock, ArrowRight, X } from 'lucide-react';
import { db } from '../database';
import { User } from '../types';
import { ADMIN_WHATSAPP } from '../constants';

const LoginPage: React.FC<{ onLogin: (u: User) => void }> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = db.getUserByEmail(email);
    
    if (user && user.password === password) {
      onLogin(user);
      navigate('/');
    } else {
      setError('E-mail ou senha incorretos.');
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Olá Luiz Paulo! Esqueci minha senha do OLX Contemporâneo. Meu e-mail cadastrado é: ${forgotEmail}. Pode me ajudar a resetar?`;
    window.open(`https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(message)}`, '_blank');
    setShowForgotModal(false);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 sm:p-12 border border-gray-100">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-600 rounded-2xl mb-4 shadow-lg shadow-indigo-100">
            <ShieldCheck className="text-white w-8 h-8" />
          </div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Bem-vindo de volta!</h2>
          <p className="text-gray-400 mt-2">Acesse os classificados exclusivos do Contemporâneo.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm font-medium text-center border border-red-100">{error}</div>}
          
          <div className="space-y-1">
            <label className="text-sm font-bold text-gray-700 ml-1">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                name="email"
                type="email" 
                required
                autoComplete="username"
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border-gray-200 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                placeholder="Ex: joao@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center ml-1">
              <label className="text-sm font-bold text-gray-700">Senha</label>
              <button 
                type="button" 
                onClick={() => setShowForgotModal(true)}
                className="text-xs font-bold text-indigo-600 hover:underline"
              >
                Esqueceu a senha?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                name="password"
                type="password" 
                required
                autoComplete="current-password"
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border-gray-200 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                placeholder="Sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-2 group"
          >
            Entrar
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="mt-8 text-center space-y-4">
          <p className="text-gray-500">Ainda não tem conta? <Link to="/cadastro" className="text-indigo-600 font-bold hover:underline">Cadastre-se como morador</Link></p>
        </div>
      </div>

      {/* Modal de Esqueci a Senha */}
      {showForgotModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-sm rounded-3xl p-8 space-y-6 shadow-2xl relative">
            <button 
              onClick={() => setShowForgotModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="text-center">
              <h3 className="text-xl font-black text-gray-900">Recuperar Senha</h3>
              <p className="text-sm text-gray-500 mt-2">Informe seu e-mail para solicitar o reset ao administrador Luiz Paulo.</p>
            </div>
            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <input 
                type="email"
                required
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Seu e-mail cadastrado"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
              />
              <button 
                type="submit"
                className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg flex items-center justify-center gap-2"
              >
                Solicitar via WhatsApp
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
