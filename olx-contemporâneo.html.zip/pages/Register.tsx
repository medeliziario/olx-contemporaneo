
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, User as UserIcon, Building, Phone, Mail, Lock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { db } from '../database';
import { User } from '../types';
import { ADMIN_EMAIL } from '../constants';

const RegisterPage: React.FC<{ onLogin: (u: User) => void }> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    name: '',
    block: '',
    apartment: '',
    whatsapp: '',
    email: '',
    password: ''
  });
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const users = db.getUsers();
      
      // Validação de Email Duplicado
      if (db.getUserByEmail(formData.email)) {
        setError('Este e-mail já está cadastrado em nosso sistema.');
        setIsLoading(false);
        return;
      }

      const isSpecialAdmin = formData.email.toLowerCase().trim() === ADMIN_EMAIL.toLowerCase().trim();
      
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        block: formData.block,
        apartment: formData.apartment,
        whatsapp: formData.whatsapp,
        email: formData.email.toLowerCase().trim(),
        password: formData.password,
        role: isSpecialAdmin ? 'admin' : 'resident',
        residentStatus: isSpecialAdmin ? 'approved' : 'pending',
        subscriberActive: isSpecialAdmin ? true : false,
        createdAt: new Date().toISOString()
      };

      // Tenta salvar no localStorage
      const success = db.saveUsers([...users, newUser]);
      
      if (!success) {
        throw new Error('Falha ao salvar dados. O armazenamento do seu navegador pode estar cheio.');
      }
      
      // Feedback de Sucesso Visual
      setIsSuccess(true);
      setIsLoading(false);

      // Aguarda um momento para o usuário ver o sucesso antes de iniciar a sessão e ser redirecionado
      setTimeout(() => {
        onLogin(newUser);
        navigate(isSpecialAdmin ? '/' : '/status');
      }, 2000);

    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro ao processar seu cadastro. Tente novamente.');
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="text-center space-y-6 animate-in fade-in zoom-in duration-500">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-green-100">
            <CheckCircle2 className="w-12 h-12 text-green-500" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-black text-gray-900 tracking-tighter">Cadastro Realizado!</h2>
            <p className="text-gray-500 font-medium">Seja bem-vindo, {formData.name.split(' ')[0]}.<br/>Redirecionando para análise...</p>
          </div>
          <Loader2 className="w-6 h-6 animate-spin text-olx-purple mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[90vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl p-8 sm:p-12 border border-gray-100">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-600 rounded-2xl mb-4 shadow-lg shadow-indigo-100">
            <ShieldCheck className="text-white w-8 h-8" />
          </div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">Cadastro de Morador</h2>
          <p className="text-gray-400 mt-2">Crie sua conta exclusiva do Condomínio Contemporâneo.</p>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-sm font-bold animate-in slide-in-from-top-2">
            <AlertCircle className="w-5 h-5 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleRegister} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1 md:col-span-2">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Nome Completo</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="Ex: João da Silva"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Bloco / Torre</label>
            <div className="relative">
              <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="Ex: 01"
                value={formData.block}
                onChange={e => setFormData({...formData, block: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Apartamento</label>
            <div className="relative">
              <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="Ex: 304"
                value={formData.apartment}
                onChange={e => setFormData({...formData, apartment: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">WhatsApp</label>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="tel"
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="21999999999"
                value={formData.whatsapp}
                onChange={e => setFormData({...formData, whatsapp: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="email"
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="joao@email.com"
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1 md:col-span-2">
            <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Senha de Acesso</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="password"
                required
                disabled={isLoading}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-gray-100 border-2 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all font-bold text-gray-700"
                placeholder="Mínimo 6 caracteres"
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full md:col-span-2 py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xl shadow-lg shadow-indigo-100 transition-all mt-4 flex items-center justify-center gap-3 disabled:bg-gray-300 disabled:shadow-none"
          >
            {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Finalizar Cadastro'}
          </button>
        </form>

        <p className="mt-8 text-center text-gray-500 font-medium">Já possui conta? <Link to="/login" className="text-indigo-600 font-bold hover:underline">Entrar agora</Link></p>
      </div>
    </div>
  );
};

export default RegisterPage;
