
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { db } from '../database';
import { User, Listing, CATEGORIES, ListingStatus } from '../types';
import { Camera, X, ArrowLeft, Loader2 } from 'lucide-react';

const EditListing: React.FC<{ user: User }> = ({ user }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: CATEGORIES[0],
    whatsapp: user.whatsapp
  });
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const l = db.getListings().find(item => item.id === id);
    if (!l || l.userId !== user.id) {
      navigate('/meus-anuncios');
      return;
    }
    setFormData({
      title: l.title,
      description: l.description,
      price: l.price.toString(),
      category: l.category,
      whatsapp: l.whatsappContact
    });
    setImages(l.images);
    setLoading(false);
  }, [id, user.id, navigate]);

  const compressImage = (base64Str: string): Promise<string> => {
    return new Promise((resolve) => {
      if (base64Str.length < 50000) return resolve(base64Str); // Já pequena
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > MAX_WIDTH) { height *= MAX_WIDTH / width; width = MAX_WIDTH; }
        } else {
          if (height > MAX_HEIGHT) { width *= MAX_HEIGHT / height; height = MAX_HEIGHT; }
        }
        canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
    });
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages: string[] = [];
      // Explicitly cast to File[] to ensure 'file' is recognized as a Blob for readAsDataURL
      for (const file of Array.from(files) as File[]) {
        const reader = new FileReader();
        const base64: string = await new Promise<string>((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          // file is an instance of File, which extends Blob
          reader.readAsDataURL(file);
        });
        const compressed = await compressImage(base64);
        newImages.push(compressed);
      }
      setImages(prev => [...prev, ...newImages].slice(0, 6));
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (images.length === 0) {
      alert('Adicione pelo menos uma foto.');
      return;
    }

    setIsSaving(true);
    const allListings = db.getListings();
    const updated: Listing[] = allListings.map(l => {
      if (l.id === id) {
        return {
          ...l,
          title: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          category: formData.category,
          whatsappContact: formData.whatsapp,
          images: images,
          status: 'pending' as ListingStatus
        };
      }
      return l;
    });

    const success = db.saveListings(updated);
    if (success) {
      alert('Alterações salvas e enviadas para re-moderação!');
      navigate('/meus-anuncios');
    } else {
      alert('Erro de espaço: Tente remover fotos ou usar imagens mais leves.');
      setIsSaving(false);
    }
  };

  if (loading) return null;

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-400 font-bold hover:text-olx-purple mb-8 transition-colors">
        <ArrowLeft className="w-5 h-5" /> Voltar
      </button>

      <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100">
        <h1 className="text-3xl font-black text-gray-900 mb-10 tracking-tighter">Editar Anúncio</h1>
        
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-4">
            <label className="text-xs font-black text-gray-900 uppercase tracking-widest">Fotos (Máx 6)</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden border border-gray-100 shadow-sm">
                  <img src={img} className="w-full h-full object-cover" alt="" />
                  <button type="button" onClick={() => removeImage(idx)} className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-lg">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {images.length < 6 && (
                <label className="aspect-square flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-2xl hover:bg-gray-50 transition-colors cursor-pointer text-gray-400">
                  <Camera className="w-8 h-8 mb-2 text-olx-purple" />
                  <span className="text-[10px] font-bold uppercase">Mudar</span>
                  <input type="file" className="hidden" accept="image/*" multiple onChange={handleImageChange} />
                </label>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Título</label>
              <input 
                required
                className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple transition-all font-medium"
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Descrição</label>
              <textarea 
                required
                className="w-full p-5 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple min-h-[120px] font-medium"
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Preço</label>
                <input 
                  type="number"
                  step="0.01"
                  required
                  className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple font-black text-xl text-olx-purple"
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: e.target.value})}
                />
              </div>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSaving}
            className="w-full py-5 bg-olx-purple text-white rounded-2xl font-black text-xl shadow-lg hover:bg-olx-purpleHover transition-all uppercase tracking-tighter flex items-center justify-center gap-3"
          >
            {isSaving ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Salvar Alterações'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditListing;
