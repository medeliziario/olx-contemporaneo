
import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { MessageCircle, ShieldCheck, MapPin, Share2, Flag, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { db } from '../database';
import { Listing, User, Report } from '../types';

const ListingDetail: React.FC<{ user: User | null }> = ({ user }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState('');
  
  const listing = db.getListings().find(l => l.id === id);

  if (!listing || (listing.status !== 'approved' && user?.role !== 'admin' && listing.userId !== user?.id)) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold">Anúncio não disponível</h2>
        <p className="text-gray-500 mt-2">Este anúncio pode ter sido removido ou o vendedor está inativo.</p>
        <Link to="/" className="inline-block mt-6 text-olx-purple font-bold">Ver outros anúncios</Link>
      </div>
    );
  }

  const handleReport = () => {
    if (!user) {
        navigate('/login');
        return;
    }
    if (!reportReason.trim()) return;
    const reports = db.getReports();
    const newReport: Report = {
      id: Math.random().toString(36).substr(2, 9),
      listingId: listing.id,
      userId: user.id,
      reason: reportReason,
      status: 'open',
      createdAt: new Date().toISOString()
    };
    db.saveReports([...reports, newReport]);
    setReportModalOpen(false);
    alert('Denúncia enviada! Analisaremos o caso.');
  };

  const whatsappLink = `https://wa.me/${listing.whatsappContact}?text=${encodeURIComponent(`Olá! Vi seu anúncio "${listing.title}" no OLX Contemporâneo. Ainda está disponível?`)}`;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left Column */}
        <div className="flex-1 space-y-6">
          <div className="bg-white rounded-3xl overflow-hidden shadow-lg relative aspect-[4/3] sm:aspect-video bg-gray-900 flex items-center justify-center">
            {listing.isFeatured && (
               <div className="absolute top-4 left-4 z-10 bg-amber-400 text-amber-900 px-4 py-2 rounded-xl text-xs font-black uppercase flex items-center gap-2 shadow-xl">
                  <Sparkles className="w-4 h-4" /> Anúncio em Destaque
               </div>
            )}
            <img 
              src={listing.images[0] || 'https://picsum.photos/800/600?random=' + listing.id} 
              alt={listing.title}
              className="max-h-full object-contain"
            />
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div>
              <h1 className="text-3xl font-black text-gray-900 tracking-tight">{listing.title}</h1>
              <div className="flex items-center gap-4 mt-2">
                  <p className="text-gray-400 text-sm font-bold uppercase">{listing.category}</p>
                  <span className="text-gray-200">|</span>
                  <p className="text-gray-400 text-sm font-medium">Postado em {new Date(listing.createdAt).toLocaleDateString('pt-BR')}</p>
              </div>
            </div>
            
            <div className="border-t border-gray-100 pt-6">
              <h3 className="text-lg font-black mb-4 uppercase tracking-widest text-gray-400">Descrição</h3>
              <p className="text-gray-700 whitespace-pre-wrap leading-relaxed text-lg">{listing.description}</p>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="lg:w-96 space-y-6">
          <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100 space-y-8 sticky top-24">
            <div className="text-center">
              <p className="text-5xl font-black text-gray-900 tracking-tighter">
                {listing.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </p>
            </div>

            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 w-full bg-green-500 hover:bg-green-600 text-white py-5 rounded-2xl font-black text-xl shadow-lg transition-all hover:-translate-y-1"
            >
              <MessageCircle className="w-7 h-7" />
              Enviar Mensagem
            </a>

            <div className="bg-gray-50 p-6 rounded-2xl flex items-center gap-4">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-olx-purple font-black text-2xl shadow-sm">
                  {listing.userName[0]}
                </div>
                <div>
                  <h4 className="font-black text-gray-900">{listing.userName}</h4>
                  <div className="flex items-center gap-1 text-olx-purple text-xs font-black uppercase tracking-tighter">
                    <ShieldCheck className="w-4 h-4" />
                    Vizinho Verificado
                  </div>
                  <p className="text-gray-400 text-xs mt-1">Bloco {listing.userBlock}</p>
                </div>
            </div>

            <div className="flex items-center justify-center gap-10 pt-4 border-t border-gray-100">
                <button className="flex flex-col items-center gap-2 text-gray-400 hover:text-olx-purple transition-colors">
                    <Share2 className="w-5 h-5" />
                    <span className="text-[10px] font-black uppercase">Compartilhar</span>
                </button>
                <button 
                  onClick={() => setReportModalOpen(true)}
                  className="flex flex-col items-center gap-2 text-gray-400 hover:text-red-600 transition-colors"
                >
                    <Flag className="w-5 h-5" />
                    <span className="text-[10px] font-black uppercase">Denunciar</span>
                </button>
            </div>
          </div>
        </div>
      </div>

      {reportModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-md rounded-3xl p-10 space-y-6">
            <h3 className="text-2xl font-black text-gray-900">Denunciar Anúncio</h3>
            <textarea
              className="w-full bg-gray-50 border-none rounded-2xl p-4 min-h-[140px] outline-none focus:ring-2 focus:ring-red-500"
              placeholder="Descreva o problema..."
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
            />
            <div className="flex gap-4">
              <button 
                onClick={() => setReportModalOpen(false)}
                className="flex-1 py-4 border border-gray-200 rounded-2xl font-black text-gray-400 hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button 
                onClick={handleReport}
                className="flex-1 py-4 bg-red-600 text-white rounded-2xl font-black hover:bg-red-700 shadow-lg"
              >
                Enviar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListingDetail;
