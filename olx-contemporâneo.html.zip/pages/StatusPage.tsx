
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Clock, MessageSquare, Loader2, Copy, CheckCircle2 } from 'lucide-react';
import { User } from '../types';
import { db } from '../database';
import { ADMIN_WHATSAPP, SUBSCRIPTION_FEE, PIX_KEY } from '../constants';

const StatusPage: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  // Polling: Verifica se o status mudou no banco a cada 3 segundos
  useEffect(() => {
    const checkStatus = setInterval(() => {
      const latestData = db.getUserById(user.id);
      if (latestData && latestData.residentStatus === 'approved') {
        // Se aprovado, limpa o intervalo e manda para a Home automaticamente
        clearInterval(checkStatus);
        window.location.href = '#/'; // Força navegação para home aprovada
      }
    }, 3000);

    return () => clearInterval(checkStatus);
  }, [user.id]);

  const contactAdmin = () => {
    const message = `Olá! Acabei de fazer o PIX de R$ ${SUBSCRIPTION_FEE},00 para o OLX Contemporâneo. Sou o ${user.name} do Bloco ${user.block} Apt ${user.apartment}. Pode liberar meu acesso?`;
    window.open(`https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(PIX_KEY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-16 text-center">
      <div className="bg-white rounded-[40px] shadow-2xl p-10 space-y-8 border border-gray-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="relative inline-flex items-center justify-center w-24 h-24">
          <div className="absolute inset-0 bg-olx-purple/10 rounded-full animate-ping"></div>
          <div className="relative z-10 bg-white rounded-full p-4 shadow-lg border border-gray-50">
            <Clock className="w-12 h-12 text-olx-purple" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter">Aguardando Aprovação</h1>
          <p className="text-gray-400 font-medium">Seu cadastro está em análise. Para liberar seu acesso agora, realize o pagamento da taxa única.</p>
        </div>
        
        <div className="bg-olx-bg rounded-3xl p-6 border border-gray-200 space-y-4">
          <div className="flex justify-between items-center border-b border-gray-200 pb-4">
            <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Valor da Taxa</span>
            <span className="text-2xl font-black text-gray-900">R$ {SUBSCRIPTION_FEE.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
          </div>
          
          <div className="space-y-2 text-left">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Chave PIX (E-mail)</label>
            <div className="relative flex items-center bg-white border border-gray-200 rounded-2xl p-4 group cursor-pointer" onClick={handleCopyPix}>
              <span className="flex-1 font-bold text-gray-700 truncate mr-8">{PIX_KEY}</span>
              <button 
                className={`absolute right-3 p-2 rounded-xl transition-all ${copied ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-olx-purple group-hover:text-white'}`}
              >
                {copied ? <CheckCircle2 className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
            {copied && <p className="text-[10px] text-green-600 font-bold uppercase text-center animate-in fade-in">Chave copiada com sucesso!</p>}
          </div>

          <div className="pt-2">
             <div className="flex items-start gap-3 text-left">
                <div className="w-6 h-6 bg-olx-purple text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">1</div>
                <p className="text-xs text-gray-500 leading-relaxed">Faça o PIX no valor de <b>R$ {SUBSCRIPTION_FEE},00</b> para a chave acima (Luiz Paulo da Silva).</p>
             </div>
             <div className="flex items-start gap-3 text-left mt-4">
                <div className="w-6 h-6 bg-olx-purple text-white rounded-full flex items-center justify-center text-[10px] font-black shrink-0 mt-0.5">2</div>
                <p className="text-xs text-gray-500 leading-relaxed">Envie o comprovante clicando no botão de WhatsApp abaixo para agilizar.</p>
             </div>
          </div>
        </div>

        <div className="pt-4 space-y-4">
            <button 
                onClick={contactAdmin}
                className="flex items-center justify-center gap-3 w-full bg-green-500 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-green-600 transition-all uppercase tracking-tighter text-lg active:scale-95"
            >
                <MessageSquare className="w-6 h-6" />
                Enviar Comprovante
            </button>
            <div className="flex items-center justify-center gap-2">
               <Loader2 className="w-4 h-4 animate-spin text-olx-purple" />
               <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                  Verificando status em tempo real...
               </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default StatusPage;