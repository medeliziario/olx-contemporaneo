
import React, { useState, useEffect } from 'react';
import { db } from '../../database';
import { User, Listing } from '../../types';
import { Users, Tag, CheckCircle, XCircle, Ban, ShieldAlert } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [listings, setListings] = useState<Listing[]>([]);

  useEffect(() => {
    setUsers(db.getUsers());
    setListings(db.getListings());
  }, []);

  const refresh = () => {
    setUsers(db.getUsers());
    setListings(db.getListings());
  };

  const updateUserStatus = (id: string, status: User['residentStatus']) => {
    const all = db.getUsers();
    const u = all.find(x => x.id === id);
    if (u) {
      u.residentStatus = status;
      if (status === 'approved') u.subscriberActive = true;
      db.saveUsers(all);
      refresh();
    }
  };

  const updateListingStatus = (id: string, status: Listing['status']) => {
    const all = db.getListings();
    const l = all.find(x => x.id === id);
    if (l) {
      l.status = status;
      db.saveListings(all);
      refresh();
    }
  };

  const deleteListing = (id: string) => {
    if (!confirm("Excluir definitivamente?")) return;
    const filtered = db.getListings().filter(l => l.id !== id);
    db.saveListings(filtered);
    refresh();
  };

  const pendingUsers = users.filter(u => u.residentStatus === 'pending');
  const activeUsers = users.filter(u => u.residentStatus === 'approved' && u.role !== 'admin');
  const pendingListings = listings.filter(l => l.status === 'pending');

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-12">
        <div className="bg-olx-purple p-3 rounded-2xl text-white">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-4xl font-black tracking-tighter text-gray-900">Central Luiz Paulo</h1>
          <p className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Controle Total do Condomínio</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* MODERAÇÃO DE MORADORES */}
        <section>
          <h2 className="text-2xl font-black mb-6 flex items-center gap-2">
            <Users className="text-olx-purple" /> Novos Moradores
          </h2>
          <div className="space-y-4">
            {pendingUsers.length > 0 ? pendingUsers.map(u => (
              <div key={u.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                <div className="mb-4">
                  <p className="font-black text-xl text-gray-900">{u.name}</p>
                  <p className="text-sm text-gray-500">Bloco {u.block} • Apto {u.apartment}</p>
                  <p className="text-xs text-gray-400 font-bold mt-1 uppercase tracking-tighter">{u.email} • {u.whatsapp}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => updateUserStatus(u.id, 'approved')} className="flex-1 bg-green-500 text-white py-3 rounded-xl font-black text-xs uppercase hover:bg-green-600 transition-colors">Aprovar</button>
                  <button onClick={() => updateUserStatus(u.id, 'rejected')} className="flex-1 bg-gray-100 text-gray-500 py-3 rounded-xl font-black text-xs uppercase hover:bg-gray-200 transition-colors">Negar</button>
                  <button onClick={() => updateUserStatus(u.id, 'blocked')} className="flex-1 bg-red-50 text-red-500 py-3 rounded-xl font-black text-xs uppercase hover:bg-red-100 transition-colors">Bloquear</button>
                </div>
              </div>
            )) : <div className="p-10 bg-gray-50 rounded-3xl text-center text-gray-400 font-bold italic">Nenhum cadastro pendente.</div>}
          </div>

          <h2 className="text-2xl font-black mb-6 mt-12 flex items-center gap-2">
            <CheckCircle className="text-green-500" /> Moradores Ativos
          </h2>
          <div className="bg-white rounded-3xl border border-gray-100 overflow-hidden">
            {activeUsers.map(u => (
              <div key={u.id} className="p-4 border-b border-gray-50 flex justify-between items-center last:border-0">
                <div>
                  <p className="font-bold text-gray-800">{u.name}</p>
                  <p className="text-[10px] text-gray-400 font-black uppercase">Bloco {u.block} - {u.apartment}</p>
                </div>
                <button onClick={() => updateUserStatus(u.id, 'blocked')} className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                  <Ban className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* MODERAÇÃO DE ANÚNCIOS */}
        <section>
          <h2 className="text-2xl font-black mb-6 flex items-center gap-2">
            <Tag className="text-olx-orange" /> Anúncios Pendentes
          </h2>
          <div className="space-y-4">
            {pendingListings.length > 0 ? pendingListings.map(l => (
              <div key={l.id} className="bg-white p-4 rounded-3xl border border-gray-100 flex items-center gap-4 shadow-sm">
                <img src={l.images[0]} className="w-20 h-20 rounded-2xl object-cover bg-gray-50" />
                <div className="flex-1">
                  <h4 className="font-bold text-gray-900 leading-tight mb-1">{l.title}</h4>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Vendedor: {l.userName}</p>
                  <p className="text-olx-purple font-black mt-1">R$ {l.price.toLocaleString()}</p>
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => updateListingStatus(l.id, 'approved')} className="bg-green-500 text-white p-2 rounded-xl" title="Aprovar"><CheckCircle className="w-5 h-5" /></button>
                  <button onClick={() => deleteListing(l.id)} className="bg-red-50 text-red-500 p-2 rounded-xl" title="Excluir"><XCircle className="w-5 h-5" /></button>
                </div>
              </div>
            )) : <div className="p-10 bg-gray-50 rounded-3xl text-center text-gray-400 font-bold italic">Nenhum anúncio para revisar.</div>}
          </div>
        </section>
      </div>
    </div>
  );
};

export default AdminDashboard;
