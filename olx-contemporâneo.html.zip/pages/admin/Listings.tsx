
import React, { useState, useEffect } from 'react';
import { db } from '../../database';
import { Listing, ListingStatus } from '../../types';
import { CheckCircle, XCircle, Trash2, Eye, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';

const AdminListings: React.FC = () => {
  const [listings, setListings] = useState<Listing[]>([]);

  useEffect(() => {
    setListings(db.getListings());
  }, []);

  const updateStatus = (id: string, status: ListingStatus) => {
    const updated = listings.map(l => l.id === id ? { ...l, status } : l);
    setListings(updated);
    db.saveListings(updated);
  };

  const deleteListing = (id: string) => {
    if (!confirm('Excluir permanentemente?')) return;
    const updated = listings.filter(l => l.id !== id);
    setListings(updated);
    db.saveListings(updated);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-10">
      <div className="flex items-center gap-3">
        <Tag className="w-10 h-10 text-olx-purple" />
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter">Moderação de Anúncios</h1>
          <p className="text-gray-400 font-medium">Anúncios novos ou editados aparecem aqui para autorização.</p>
        </div>
      </div>

      <div className="grid gap-6">
        {listings.map(l => (
          <div key={l.id} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-center gap-6">
            <div className="w-32 h-32 rounded-2xl overflow-hidden bg-gray-100 shrink-0">
              <img src={l.images[0]} className="w-full h-full object-cover" alt="" />
            </div>
            <div className="flex-1">
               <div className="flex items-center gap-3 mb-2">
                 <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                   l.status === 'approved' ? 'bg-green-100 text-green-700' : 
                   l.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                 }`}>
                   {l.status === 'approved' ? 'Aprovado / Online' : l.status === 'pending' ? 'Aguardando Autorização' : 'Recusado'}
                 </span>
                 <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">{l.category}</span>
               </div>
               <h4 className="font-bold text-gray-900 text-xl tracking-tight">{l.title}</h4>
               <p className="text-olx-purple font-black text-2xl">{l.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
               <p className="text-xs text-gray-400 font-bold mt-2 uppercase tracking-wide">
                 Vendedor: {l.userName} (Bloco {l.userBlock})
               </p>
            </div>
            
            <div className="flex gap-3 bg-gray-50 p-4 rounded-3xl border border-gray-100">
              <Link to={`/listing/${l.id}`} className="p-3 bg-white text-gray-400 rounded-2xl hover:text-olx-purple transition-colors shadow-sm" title="Ver Detalhes">
                <Eye className="w-7 h-7" />
              </Link>
              
              {l.status !== 'approved' && (
                <button 
                  onClick={() => updateStatus(l.id, 'approved')} 
                  className="p-3 bg-green-500 text-white rounded-2xl hover:bg-green-600 transition-all shadow-md flex items-center gap-2 font-black uppercase text-xs"
                >
                  <CheckCircle className="w-7 h-7" /> Autorizar
                </button>
              )}
              
              {l.status === 'approved' && (
                <button 
                  onClick={() => updateStatus(l.id, 'rejected')} 
                  className="p-3 bg-red-100 text-red-600 rounded-2xl hover:bg-red-200 transition-all shadow-sm"
                  title="Recusar Anúncio"
                >
                  <XCircle className="w-7 h-7" />
                </button>
              )}
              
              <button onClick={() => deleteListing(l.id)} className="p-3 bg-white text-red-200 rounded-2xl hover:text-red-600 transition-colors shadow-sm" title="Excluir">
                <Trash2 className="w-7 h-7" />
              </button>
            </div>
          </div>
        ))}
        {listings.length === 0 && (
          <div className="text-center py-32 bg-white rounded-3xl border border-dashed border-gray-200 text-gray-400 font-bold">
            Nenhum anúncio no sistema.
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminListings;
