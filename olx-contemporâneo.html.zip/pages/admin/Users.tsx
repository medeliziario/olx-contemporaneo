
import React, { useState, useEffect } from 'react';
import { db } from '../../database';
import { User, ResidentStatus } from '../../types';
import { CheckCircle, XCircle, Ban, Shield, MessageCircle, Table, CheckSquare, ExternalLink, Clock, RotateCcw } from 'lucide-react';
import { SUBSCRIPTION_FEE } from '../../constants';

interface UserRowProps {
  user: User;
  updateStatus: (userId: string, status: ResidentStatus, activateSub?: boolean) => void;
  toggleSubscription: (userId: string, active: boolean) => void;
  renewSubscription: (userId: string) => void;
}

const UserRow: React.FC<UserRowProps> = ({ user, updateStatus, toggleSubscription, renewSubscription }) => {
  const isExpired = user.subscriptionExpiresAt && new Date(user.subscriptionExpiresAt) < new Date();
  
  const sendWelcomeMessage = () => {
    const message = `Olá ${user.name}! Bem-vindo ao OLX Contemporâneo. Recebemos seu cadastro (Bloco ${user.block} - ${user.apartment}). Em breve enviaremos o link de pagamento de R$ ${SUBSCRIPTION_FEE},00 para confirmar seu acesso e liberar suas publicações de anúncios. Aguarde nosso contato!`;
    const url = `https://wa.me/${user.whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
      <td className="py-4 px-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-olx-purple/10 rounded-full flex items-center justify-center text-olx-purple font-black">
            {user.name[0]}
          </div>
          <div>
            <p className="font-bold text-gray-900">{user.name}</p>
            <p className="text-[10px] font-medium text-gray-400 uppercase tracking-widest">{user.email}</p>
          </div>
        </div>
      </td>
      <td className="py-4 font-bold text-gray-600 text-sm">
        Bloco {user.block} - {user.apartment}
      </td>
      <td className="py-4">
        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
          isExpired ? 'bg-red-600 text-white' :
          user.residentStatus === 'approved' ? 'bg-green-100 text-green-700' :
          user.residentStatus === 'rejected' ? 'bg-red-100 text-red-700' :
          user.residentStatus === 'blocked' ? 'bg-gray-800 text-white' : 'bg-yellow-100 text-yellow-700'
        }`}>
          {isExpired ? 'Expirado (30d)' : 
           user.residentStatus === 'pending' ? 'Pendente' : 
           user.residentStatus === 'approved' ? 'Aprovado' :
           user.residentStatus === 'rejected' ? 'Reprovado' : 'Inadimplente'}
        </span>
      </td>
      <td className="py-4">
        <div className="flex items-center gap-2">
            <button 
              onClick={sendWelcomeMessage}
              className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 border border-green-200" 
              title="Enviar Boas-vindas"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
            {user.residentStatus === 'pending' && (
                <button 
                    onClick={() => updateStatus(user.id, 'approved', true)} 
                    className="flex items-center gap-1 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 shadow-sm transition-all text-[10px] font-black uppercase" 
                >
                    <CheckSquare className="w-4 h-4" /> Aprovar
                </button>
            )}
            {(user.residentStatus === 'approved' || isExpired) && (
                <button 
                    onClick={() => renewSubscription(user.id)}
                    className="flex items-center gap-1 px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 shadow-sm transition-all text-[10px] font-black uppercase"
                    title="Renovar +30 Dias"
                >
                    <RotateCcw className="w-4 h-4" /> Renovar 30d
                </button>
            )}
        </div>
      </td>
      <td className="py-4 px-6 text-right">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Expira em:</p>
        <p className={`text-xs font-bold ${isExpired ? 'text-red-600' : 'text-gray-900'}`}>
            {user.subscriptionExpiresAt ? new Date(user.subscriptionExpiresAt).toLocaleDateString('pt-BR') : 'Não iniciado'}
        </p>
      </td>
    </tr>
  );
};

const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    setUsers(db.getUsers());
  }, []);

  const updateStatus = (userId: string, status: ResidentStatus, activateSub: boolean = false) => {
    const updated = users.map(u => {
      if (u.id === userId) {
        return { 
            ...u, 
            residentStatus: status,
            subscriberActive: activateSub ? true : u.subscriberActive 
        };
      }
      return u;
    });
    setUsers(updated);
    db.saveUsers(updated);
  };

  const renewSubscription = (userId: string) => {
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30);
    
    const updated = users.map(u => u.id === userId ? { 
        ...u, 
        subscriptionExpiresAt: expiryDate.toISOString(),
        subscriberActive: true,
        residentStatus: 'approved' as ResidentStatus
    } : u);
    
    setUsers(updated);
    db.saveUsers(updated);
    alert('Acesso renovado por mais 30 dias!');
  };

  const toggleSubscription = (userId: string, active: boolean) => {
    const updated = users.map(u => u.id === userId ? { ...u, subscriberActive: active } : u);
    setUsers(updated);
    db.saveUsers(updated);
  };

  const exportToCSV = () => {
    const headers = ['Nome', 'Email', 'WhatsApp', 'Bloco', 'Apartamento', 'Status', 'Expira Em'];
    const rows = users.map(u => [
      `"${u.name}"`,
      `"${u.email}"`,
      `"${u.whatsapp}"`,
      `"${u.block}"`,
      `"${u.apartment}"`,
      `"${u.residentStatus}"`,
      `"${u.subscriptionExpiresAt ? new Date(u.subscriptionExpiresAt).toLocaleDateString('pt-BR') : 'Pendente'}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `contemporaneo_database.csv`);
    link.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-3">
          <Shield className="w-10 h-10 text-olx-purple" />
          <div>
            <h1 className="text-3xl font-black text-gray-900 tracking-tighter">Gestão de Moradores</h1>
            <p className="text-gray-400 font-medium">Controle de aprovação e ciclos de 30 dias.</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
            <button 
                onClick={exportToCSV}
                className="flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-2xl font-black uppercase tracking-tighter hover:bg-green-700 transition-all shadow-lg"
            >
                <Table className="w-5 h-5" /> Exportar Dados
            </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50/50 text-gray-400 text-[10px] font-black uppercase tracking-widest">
              <tr>
                <th className="px-6 py-5">Morador</th>
                <th className="py-5">Localização</th>
                <th className="py-5">Status</th>
                <th className="py-5">Ações</th>
                <th className="px-6 py-5 text-right">Ciclo 30d</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <UserRow 
                  key={u.id} 
                  user={u} 
                  updateStatus={updateStatus} 
                  toggleSubscription={toggleSubscription}
                  renewSubscription={renewSubscription}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminUsers;
