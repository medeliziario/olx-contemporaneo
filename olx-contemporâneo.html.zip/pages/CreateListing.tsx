
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../database';
import { User, Listing, CATEGORIES } from '../types';
import { Camera, X, Loader2 } from 'lucide-react';

const CreateListing: React.FC<{ user: User }> = ({ user }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: CATEGORIES[0],
    whatsapp: user.whatsapp
  });
  const [images, setImages] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const navigate = useNavigate();

  const compressImage = (base64Str: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.7));
      };
    });
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      setIsUploading(true);
      const newImages: string[] = [];
      // Explicitly cast to File[] to ensure 'file' is recognized as a Blob for readAsDataURL
      for (const file of Array.from(files) as File[]) {
        const reader = new FileReader();
        const base64: string = await new Promise<string>((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          // file is an instance of File, which extends Blob
          reader.readAsDataURL(file);
        });
        const compressed = await compressImage(base64);
        newImages.push(compressed);
      }
      setImages(prev => [...prev, ...newImages].slice(0, 6));
      setIsUploading(false);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Verifica se o acesso já expirou antes de salvar
    if (user.subscriptionExpiresAt && new Date(user.subscriptionExpiresAt) < new Date()) {
        alert('Seu tempo de publicação expirou. Por favor, realize a renovação com o administrador.');
        navigate('/meus-anuncios');
        return;
    }

    if (images.length === 0) {
      alert('Por favor, adicione pelo menos uma foto.');
      return;
    }

    setIsSaving(true);
    
    const isFeatured = user.planType === 'premium' || user.planType === 'pro';

    const newListing: Listing = {
      id: Math.random().toString(36).substr(2, 9),
      title: formData.title,
      description: formData.description,
      price: parseFloat(formData.price),
      category: formData.category,
      whatsappContact: formData.whatsapp,
      images: images,
      userId: user.id,
      userName: user.name,
      userBlock: user.block,
      status: 'pending',
      isFeatured: isFeatured,
      createdAt: new Date().toISOString()
    };

    const listings = db.getListings();
    const success = db.saveListings([...listings, newListing]);

    if (success) {
      // Se for a PRIMEIRA publicação, inicia o contador de 30 dias
      if (!user.subscriptionExpiresAt) {
        const users = db.getUsers();
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 30);
        
        const updatedUsers = users.map(u => u.id === user.id ? {
            ...u,
            subscriptionExpiresAt: expiryDate.toISOString()
        } : u);
        
        db.saveUsers(updatedUsers);
      }

      alert('Anúncio enviado para moderação! Como este é seu ciclo de 30 dias, ele já começou a contar.');
      navigate('/meus-anuncios');
    } else {
      alert('Erro ao salvar. Tente novamente.');
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100">
        <h1 className="text-3xl font-black text-gray-900 mb-2 tracking-tight">Anunciar Desapego</h1>
        <p className="text-gray-400 mb-10">Seu anúncio será revisado e ficará online no ciclo de 30 dias.</p>
        
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-4">
            <label className="text-sm font-black text-gray-900 uppercase tracking-widest flex items-center gap-2">
              Fotos {isUploading && <Loader2 className="w-4 h-4 animate-spin text-olx-purple" />}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden border border-gray-100 shadow-sm group">
                  <img src={img} className="w-full h-full object-cover" alt="" />
                  <button 
                    type="button"
                    onClick={() => removeImage(idx)}
                    className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {images.length < 6 && (
                <label className="aspect-square flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-2xl hover:bg-gray-50 transition-colors cursor-pointer text-gray-400">
                  <Camera className="w-8 h-8 mb-2 text-olx-purple" />
                  <span className="text-[10px] font-bold uppercase">Adicionar</span>
                  <input type="file" className="hidden" accept="image/*" multiple onChange={handleImageChange} disabled={isUploading} />
                </label>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Título do Anúncio</label>
              <input 
                required
                className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple transition-all text-gray-900 font-medium"
                placeholder="Ex: Bicicleta Aro 29 seminova"
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Descrição</label>
              <textarea 
                required
                className="w-full p-5 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple min-h-[120px] text-gray-900 font-medium"
                placeholder="Conte detalhes do produto..."
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Categoria</label>
                <select 
                  className="w-full p-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple font-medium text-gray-700"
                  value={formData.category}
                  onChange={e => setFormData({...formData, category: e.target.value})}
                >
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest">Preço</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">R$</span>
                  <input 
                    type="number"
                    step="0.01"
                    required
                    className="w-full pl-12 pr-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-olx-purple font-black text-xl text-olx-purple"
                    placeholder="0,00"
                    value={formData.price}
                    onChange={e => setFormData({...formData, price: e.target.value})}
                  />
                </div>
              </div>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSaving || isUploading}
            className="w-full py-5 bg-olx-orange hover:bg-olx-orange/90 text-white rounded-2xl font-black text-xl shadow-lg transition-all transform hover:-translate-y-1 uppercase tracking-tighter flex items-center justify-center gap-3 disabled:bg-gray-300 disabled:transform-none"
          >
            {isSaving ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Publicar Anúncio'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateListing;
