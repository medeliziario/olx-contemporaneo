
import React from 'react';
import { CreditCard, MessageSquare, CheckCircle, Sparkles, Rocket, Zap } from 'lucide-react';
import { ADMIN_WHATSAPP, SUBSCRIPTION_FEE } from '../constants';

const SubscriptionRequired: React.FC = () => {
  const plans = [
    {
      name: 'Essencial',
      price: SUBSCRIPTION_FEE,
      icon: Zap,
      color: 'indigo',
      features: ['Anúncios ilimitados', 'Venda via WhatsApp', 'Acesso morador'],
      popular: false
    },
    {
      name: 'Destaque+',
      price: 29,
      icon: Sparkles,
      color: 'amber',
      features: ['Selo Destaque nos itens', 'Aparece no topo da lista', 'Fotos com mais qualidade'],
      popular: true
    },
    {
      name: 'Profissional',
      price: 49,
      icon: Rocket,
      color: 'purple',
      features: ['Vitrine exclusiva', 'Impulsionamento semanal', 'Suporte VIP admin'],
      popular: false
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-20 text-center">
      <div className="space-y-4 mb-16">
          <h1 className="text-5xl font-black text-gray-900 tracking-tighter">Escolha seu Plano</h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto">Venda mais rápido com os nossos planos profissionais exclusivos para moradores.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <div key={plan.name} className={`bg-white rounded-[40px] p-10 flex flex-col border-2 transition-all hover:scale-105 ${plan.popular ? 'border-amber-400 shadow-2xl shadow-amber-100' : 'border-gray-100 shadow-xl'}`}>
            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mb-6 mx-auto ${plan.popular ? 'bg-amber-100 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
              <plan.icon className="w-8 h-8" />
            </div>
            
            {plan.popular && <span className="text-amber-500 font-black text-[10px] uppercase tracking-widest mb-2">Mais Vendido</span>}
            <h3 className="text-2xl font-black text-gray-900 mb-2">{plan.name}</h3>
            
            <div className="my-6">
                <span className="text-5xl font-black text-gray-900">R$ {plan.price}</span>
                <span className="text-gray-400 font-bold">/mês</span>
            </div>

            <ul className="text-left space-y-4 mb-10 flex-1">
                {plan.features.map(f => (
                  <li key={f} className="flex items-center gap-3 text-gray-600 font-medium text-sm">
                      <CheckCircle className={`w-5 h-5 ${plan.popular ? 'text-amber-500' : 'text-green-500'}`} /> {f}
                  </li>
                ))}
            </ul>

            <a 
                href={`https://wa.me/${ADMIN_WHATSAPP}?text=Olá! Quero assinar o plano ${plan.name} no OLX Contemporâneo.`}
                className={`w-full py-4 rounded-2xl font-black text-lg transition-all shadow-lg flex items-center justify-center gap-2 ${
                  plan.popular ? 'bg-amber-400 hover:bg-amber-500 text-amber-900' : 'bg-gray-900 hover:bg-black text-white'
                }`}
            >
                Ativar Agora
            </a>
          </div>
        ))}
      </div>

      <div className="mt-16 text-gray-400 font-medium">
          <p>O pagamento é via PIX para a administração do condomínio.</p>
          <button onClick={() => window.history.back()} className="mt-4 hover:text-olx-purple font-bold">Voltar</button>
      </div>
    </div>
  );
};

export default SubscriptionRequired;
