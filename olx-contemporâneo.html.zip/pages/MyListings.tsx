
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { db } from '../database';
import { User, Listing } from '../types';
import { Edit3, Trash2, Eye, Plus, AlertCircle, CheckCircle, Clock, Copy, CheckCircle2, MessageSquare } from 'lucide-react';
import { ADMIN_WHATSAPP, SUBSCRIPTION_FEE, PIX_KEY } from '../constants';

const MyListings: React.FC<{ user: User }> = ({ user }) => {
  const [listings, setListings] = useState<Listing[]>([]);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();

  // Atualiza dados do usuário localmente para garantir status real
  const currentUser = db.getUserById(user.id) || user;

  useEffect(() => {
    const allListings = db.getListings();
    setListings(allListings.filter(l => l.userId === user.id));
  }, [user.id]);

  const isExpired = currentUser.subscriptionExpiresAt && new Date(currentUser.subscriptionExpiresAt) < new Date();
  const daysLeft = currentUser.subscriptionExpiresAt 
    ? Math.max(0, Math.ceil((new Date(currentUser.subscriptionExpiresAt).getTime() - new Date().getTime()) / (1000 * 3600 * 24)))
    : null;

  const handleDelete = (id: string) => {
    if (!confirm('Deseja excluir este anúncio permanentemente?')) return;
    const all = db.getListings();
    const updated = all.filter(l => l.id !== id);
    db.saveListings(updated);
    setListings(listings.filter(l => l.id !== id));
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(PIX_KEY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const contactAdminRenewal = () => {
    const message = `Olá Luiz Paulo! Gostaria de renovar meu acesso de 30 dias no OLX Contemporâneo. Já realizei o PIX de R$ ${SUBSCRIPTION_FEE},00. Sou o ${currentUser.name} do Bloco ${currentUser.block}.`;
    window.open(`https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      {/* Banner de Expiração */}
      {currentUser.subscriptionExpiresAt && (
        <div className={`mb-8 p-6 rounded-3xl border-2 flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-4 ${isExpired ? 'bg-red-50 border-red-100' : 'bg-amber-50 border-amber-100'}`}>
            <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isExpired ? 'bg-red-500 text-white' : 'bg-amber-500 text-white'}`}>
                    <Clock className="w-6 h-6" />
                </div>
                <div>
                    <h3 className={`font-black uppercase tracking-tighter text-lg ${isExpired ? 'text-red-700' : 'text-amber-700'}`}>
                        {isExpired ? 'Acesso Expirado' : `Acesso vence em ${daysLeft} dias`}
                    </h3>
                    <p className="text-gray-500 text-sm font-medium">
                        {isExpired ? 'Realize o pagamento para voltar a anunciar.' : 'Seu ciclo de 30 dias está chegando ao fim.'}
                    </p>
                </div>
            </div>
            
            {isExpired && (
                <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                    <div className="bg-white px-4 py-2 rounded-xl border border-gray-200 flex items-center gap-2 cursor-pointer group" onClick={handleCopyPix}>
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">PIX:</span>
                        <span className="text-xs font-bold text-gray-700">{PIX_KEY}</span>
                        {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-gray-300 group-hover:text-olx-purple" />}
                    </div>
                    <button 
                        onClick={contactAdminRenewal}
                        className="bg-olx-purple text-white px-6 py-2 rounded-xl font-black uppercase text-xs shadow-lg hover:bg-olx-purpleHover transition-all flex items-center gap-2"
                    >
                        <MessageSquare className="w-4 h-4" /> Enviar Comprovante
                    </button>
                </div>
            )}
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter">Meus Anúncios</h1>
          <p className="text-gray-400 font-medium">Gerencie suas publicações ativas.</p>
        </div>
        <button 
          onClick={() => isExpired ? alert('Acesso expirado. Renove seu plano para anunciar.') : navigate('/anunciar')}
          disabled={isExpired}
          className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-black uppercase tracking-tighter shadow-lg transition-transform ${isExpired ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-olx-orange text-white hover:scale-105'}`}
        >
          <Plus className="w-5 h-5" /> Novo Anúncio
        </button>
      </div>

      <div className="space-y-4">
        {listings.length > 0 ? listings.map(l => (
          <div key={l.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-center gap-6">
            <div className="w-24 h-24 rounded-2xl overflow-hidden bg-gray-100 shrink-0">
              <img src={l.images[0]} className="w-full h-full object-cover" alt="" />
            </div>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                {l.status === 'approved' ? (
                  <span className="flex items-center gap-1 text-[10px] font-black uppercase text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                    <CheckCircle className="w-3 h-3" /> Ativo
                  </span>
                ) : l.status === 'pending' ? (
                  <span className="flex items-center gap-1 text-[10px] font-black uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                    <AlertCircle className="w-3 h-3" /> Em Moderação
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10px] font-black uppercase text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
                    <AlertCircle className="w-3 h-3" /> Recusado
                  </span>
                )}
                <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">{l.category}</span>
              </div>
              <h3 className="font-bold text-gray-900 text-lg leading-tight">{l.title}</h3>
              <p className="text-olx-purple font-black text-xl">{l.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
            </div>

            <div className="flex items-center gap-3">
              <Link to={`/listing/${l.id}`} className="p-3 text-gray-400 hover:text-olx-purple transition-colors bg-gray-50 rounded-2xl" title="Visualizar">
                <Eye className="w-6 h-6" />
              </Link>
              {!isExpired && (
                  <Link to={`/editar-anuncio/${l.id}`} className="p-3 text-gray-400 hover:text-blue-600 transition-colors bg-gray-50 rounded-2xl" title="Editar">
                    <Edit3 className="w-6 h-6" />
                  </Link>
              )}
              <button onClick={() => handleDelete(l.id)} className="p-3 text-gray-400 hover:text-red-600 transition-colors bg-gray-50 rounded-2xl" title="Excluir">
                <Trash2 className="w-6 h-6" />
              </button>
            </div>
          </div>
        )) : (
          <div className="bg-white p-20 rounded-3xl border border-dashed border-gray-200 text-center">
            <p className="text-gray-400 font-medium">Você ainda não tem anúncios publicados.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyListings;
