
import { User, Listing, Report } from './types';
import { ADMIN_EMAIL, ADMIN_WHATSAPP } from './constants';

const USERS_KEY = 'olx_contemporaneo_users_v3';
const LISTINGS_KEY = 'olx_contemporaneo_listings_v3';
const REPORTS_KEY = 'olx_contemporaneo_reports_v3';
const SESSION_KEY = 'olx_contemporaneo_session_v3';

const safeGet = <T>(key: string): T[] => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

export const db = {
  getUsers: (): User[] => safeGet<User>(USERS_KEY),
  // Updated to return boolean to fix potential truthiness check errors and handle quota limits
  saveUsers: (users: User[]): boolean => {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      return true;
    } catch (e) {
      return false;
    }
  },
  
  getListings: (): Listing[] => safeGet<Listing>(LISTINGS_KEY),
  // Updated to return boolean to fix "An expression of type 'void' cannot be tested for truthiness" error in components
  saveListings: (listings: Listing[]): boolean => {
    try {
      localStorage.setItem(LISTINGS_KEY, JSON.stringify(listings));
      return true;
    } catch (e) {
      return false;
    }
  },

  // Added missing getReports method required by ListingDetail.tsx
  getReports: (): Report[] => safeGet<Report>(REPORTS_KEY),
  // Added missing saveReports method required by ListingDetail.tsx
  saveReports: (reports: Report[]): boolean => {
    try {
      localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
      return true;
    } catch (e) {
      return false;
    }
  },
  
  getSession: () => localStorage.getItem(SESSION_KEY),
  setSession: (id: string | null) => id ? localStorage.setItem(SESSION_KEY, id) : localStorage.removeItem(SESSION_KEY),
  
  getUserById: (id: string) => db.getUsers().find(u => u.id === id),
  getUserByEmail: (email: string) => db.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase()),

  init: () => {
    const users = db.getUsers();
    let admin = users.find(u => u.email === ADMIN_EMAIL);
    
    if (!admin) {
      users.push({
        id: 'admin-luiz-paulo',
        name: 'Luiz Paulo',
        email: ADMIN_EMAIL,
        password: 'luiz123',
        whatsapp: ADMIN_WHATSAPP,
        block: 'ADMIN',
        apartment: 'ADMIN',
        role: 'admin',
        residentStatus: 'approved',
        subscriberActive: true,
        createdAt: new Date().toISOString()
      });
      db.saveUsers(users);
    }
  }
};
